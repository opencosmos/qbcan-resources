# qbcan

Open Cosmos qbcan is a CanSat bus design to achieve a low-cost, simple assembly and excellent performance.

It includes:

* Arduino Pro Micro - Microcontroller
* BMP180 - Pressure and Temperature Sensor
* RFM69 - Long Range 433 MHz Transceiver.

## Folder Structure

This repo contains the following folders.

* Datasheets - Contains all the datasheets of the parts used.
* Docs - Contains the documentation (i.e. the user manual).
* PCB - Contains the QBcan PCB design (for Eagle).
* References - External Documents.
* Software - on-board software.

## Contributors

* Josep Virgili Llop
* Cristóbal Nieto
* Rafel Jordà Siquier